# @smm/modkit

The **Milkshake Mania mod authoring kit** (v1.4) — TypeScript types and a thin
runtime shim for the API the game injects into every code mod.

It exists so your mod source **type-checks and autocompletes**. The game itself
provides the real objects at runtime and resolves `require("@smm/modkit")`, so
you never ship this package inside your mod zip.

## Use it

Point your `tsconfig.json` at it (either install it, or reference the folder):

```jsonc
{
  "compilerOptions": {
    "paths": { "@smm/modkit": ["../modkit/index.d.ts"] }
  }
}
```

Then write your mod against it:

```ts
import { hooks, gameApi, events, storage, ui } from "@smm/modkit";

hooks.append("game/logic.ts@calcGlobalMultiplier", (v) => v * 1.1);

ui.addMenuButton({
  label: "Hello",
  icon: "sparkles",
  onClick: () => ui.notify("Hi from my mod!", { tone: "success", icon: "star" }),
});
```

## Build

A code mod ships a single compiled `dist/main.js`. You write TypeScript in
`src/`, then **transpile + bundle** it, marking `@smm/modkit` as **external**
so it isn't inlined — the game supplies it at runtime.

**If you downloaded this kit from the wiki**, it already contains everything:
`build.mjs` (the build script), `tsconfig.json` (type-checking config), and
this `modkit/` folder (the types). Layout your workspace like this:

```
my-mods/
  modkit/          <- from this download
  build.mjs        <- from this download
  tsconfig.json    <- from this download
  my_first_mod/
    mod.json
    src/main.ts
```

Then (needs Node.js + `npm i esbuild` once):

```
node build.mjs               # builds every mod folder with a src/ entry
node build.mjs my_first_mod  # or just one
tsc -p tsconfig.json         # optional: type-check your source
```

Zip `my_first_mod/` and install it from the game's Mods panel. Done.

The repo ships a real, runnable build for the example mods that does exactly
this (it's the same command a mod author runs), at `example_mods/build.mjs`:

```
# from the repo root — builds every example mod that has a src/ entry
node example_mods/build.mjs

# or just one:
node example_mods/build.mjs journal_plus
```

It calls esbuild with the correct settings (`--bundle --format=cjs
--platform=browser --target=es2020 --external:@smm/modkit`). The equivalent
one-liner for your own mod:

```
esbuild src/main.ts --bundle --format=cjs --platform=browser --external:@smm/modkit --outfile=dist/main.js
```

Type-check while you author with the shared config at
`example_mods/tsconfig.json` (it maps `@smm/modkit` to this kit's `index.d.ts`,
so imports resolve without installing anything):

```
tsc -p example_mods/tsconfig.json
```

The `example_mods/*/dist/main.js` files in this repo are **genuinely produced
by `build.mjs`** from their `src/`, not hand-written. Rebuild them any time you
edit a mod's source. (You can also skip the import and use the injected globals
directly — `hooks`, `gameApi`, `events`, `storage`, `ui`, `mods`, `crash`,
`register` — but importing from `@smm/modkit` is what gives you types.)

## What's in scope

`hooks`, `gameApi` (incl. `gameApi.stats()`), `events`, `storage` (per-save, with
`storage.global`), `ui` (modal / notify / confirm / prompt / addMenuButton /
icons), `mods`, `crash(reason)`, and `register` (imperative content). See
`index.d.ts` for the full signatures, or `../docs.md` and the wiki's **Hook &
registry reference** for prose.
