/**
 * @smm/modkit — runtime shim (v1.4).
 *
 * The game injects the real modding API into every code mod's scope AND resolves
 * `require("@smm/modkit")` to that same bundle, so in-game this file is never
 * actually used. It exists only so the package resolves outside the game (e.g.
 * a bundler that inlines it, or tooling that imports it): it forwards to the
 * globals the loader defines. Prefer marking `@smm/modkit` as EXTERNAL in your
 * build so the loader supplies the live objects instead.
 */
"use strict";

var g = typeof globalThis !== "undefined" ? globalThis : this;

function pick(name) {
  return g && g[name];
}

module.exports = {
  get hooks() {
    return pick("hooks");
  },
  get gameApi() {
    return pick("gameApi");
  },
  get events() {
    return pick("events");
  },
  get storage() {
    return pick("storage");
  },
  get ui() {
    return pick("ui");
  },
  get mods() {
    return pick("mods");
  },
  get crash() {
    return pick("crash");
  },
  get register() {
    return pick("register");
  },
};
