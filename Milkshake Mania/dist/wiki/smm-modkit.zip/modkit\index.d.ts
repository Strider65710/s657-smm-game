/**
 * @smm/modkit — the Milkshake Mania mod authoring kit (v1.4).
 *
 * These are TYPES + a thin runtime shim for the values the game injects into
 * every code mod's scope. You do NOT ship this package inside your mod: the
 * game provides the real objects at runtime (and resolves `require("@smm/modkit")`
 * itself). Import from it only so your TypeScript type-checks and autocompletes:
 *
 *   import { hooks, gameApi, events, storage, ui } from "@smm/modkit";
 *
 * When you bundle your mod to `dist/main.js`, mark `@smm/modkit` as EXTERNAL
 * (don't inline it) — the loader supplies it. Or skip the import entirely and
 * use the injected globals directly, as the compiled example mods do.
 */

// ── hooks ────────────────────────────────────────────────────────────────────
export type HookAppendFn = (value: any, ctx?: any) => any;
export type HookPrependFn = (ctx?: any) => void;
export type HookOverrideFn = (ctx?: any) => any;

export interface Hooks {
  /** Run AFTER the game computes the value; return a replacement. Stacks. */
  append(id: string, fn: HookAppendFn): void;
  /** Run BEFORE (observe inputs); return value ignored. Stacks. */
  prepend(id: string, fn: HookPrependFn): void;
  /** REPLACE the computed value. Last registered wins; conflicts are warned. */
  override(id: string, fn: HookOverrideFn): void;
}
export const hooks: Hooks;

// ── gameApi ──────────────────────────────────────────────────────────────────
export interface StatsSnapshot {
  money: number;
  totalLifetimeMoney: number;
  totalMilkshakes: number;
  specials: {
    fanFavorite: number;
    creamy: number;
    crusty: number;
    baked: number;
    golden: number;
    swirled: number;
    decorated: number;
  };
  gameDays: number;
  level: number;
  xpTotal: number;
  prestigeLevel: number;
  prestigeTokens: number;
  prestigeTokensEarned: number;
  unlockedFlavors: number;
  activeFlavors: number;
  unlockedCountries: number;
  earnedAchievements: number;
  shops: number;
  locations: number;
  totalChoiceEvents: number;
  totalAutoEvents: number;
  records: {
    peakIncomePerSec: number;
    peakMoneyHeld: number;
    mostBlendsSession: number;
    bestSpecialStreak: number;
  };
  gameMode: "easy" | "normal" | "hard";
  businessName: string;
}

export interface GameApi {
  readonly apiVersion: string;
  readonly format: {
    money(n: number): string;
    number(n: number): string;
  };
  readonly constants: {
    BASE_SHAKE_SALE: number;
    TAX_RATE: number;
    PROFIT_DIVISOR: number;
    INITIAL_BLEND_TIME: number;
  };
  readonly registry: {
    flavors(): { id: string; name: string; multiplier: number; unlockCost: number }[];
    countries(): { id: string; name: string; multiplier: number; cost: number }[];
  };
  /** A snapshot of the active save's real progress, or null if none is open. */
  stats(): StatsSnapshot | null;
  /**
   * The catalog of every hookable point: `[{ id, kind, desc }]`. Use an `id`
   * with `hooks.append/prepend/override`. `kind` is "value" (transforms a
   * return value) or "input" (observe inputs via `prepend`).
   */
  hooks(): { id: string; kind: "value" | "input"; desc: string }[];
}
export const gameApi: GameApi;

// ── events ───────────────────────────────────────────────────────────────────
export interface BlendPayload {
  gain: number;
  special: boolean;
}
export interface PrestigePayload {
  level: number;
}
export interface SaveChangedPayload {
  saveId: string | null;
  stats: StatsSnapshot | null;
}
export interface Events {
  on(event: "blend", fn: (p: BlendPayload) => void): void;
  on(event: "prestige", fn: (p: PrestigePayload) => void): void;
  on(event: "saveChanged", fn: (p: SaveChangedPayload) => void): void;
  on(event: string, fn: (p?: any) => void): void;
}
export const events: Events;

// ── storage (per-save by default; .global persists across saves) ──────────────
export interface StorageScope {
  get<T = unknown>(key: string, fallback?: T): T;
  set(key: string, value: unknown): void;
  remove(key: string): void;
  keys(): string[];
}
export interface ModStorage extends StorageScope {
  readonly global: StorageScope;
}
export const storage: ModStorage;

// ── ui ─────────────────────────────────────────────────────────────────────
export type ToastTone = "info" | "success" | "warn";
export interface Ui {
  addMenuButton(opts: { label: string; icon?: string; onClick: () => void }): void;
  modal(opts: {
    title?: string;
    icon?: string;
    text?: string;
    html?: string;
    closeLabel?: string;
  }): void;
  notify(
    message: string,
    opts?: { tone?: ToastTone; icon?: string; durationMs?: number },
  ): void;
  confirm(opts: {
    title?: string;
    text?: string;
    icon?: string;
    confirmLabel?: string;
    cancelLabel?: string;
  }): Promise<boolean>;
  prompt(opts: {
    title?: string;
    text?: string;
    icon?: string;
    placeholder?: string;
    defaultValue?: string;
    confirmLabel?: string;
    cancelLabel?: string;
  }): Promise<string | null>;
  /** Valid Lucide icon names accepted by the `icon` fields above. */
  icons(): string[];
}
export const ui: Ui;

// ── mods (introspection) ──────────────────────────────────────────────────────
export interface ModInfo {
  readonly namespace: string;
  readonly displayName: string;
  readonly version: string;
  readonly type: "asset" | "code" | "lib";
}
export interface Mods {
  list(): ModInfo[];
  has(namespace: string): boolean;
  get(namespace: string): ModInfo | undefined;
}
export const mods: Mods;

// ── crash (controlled emergency exit) ─────────────────────────────────────────
export function crash(reason?: string): never;

// ── register (imperative content registration; mirrors registry.json) ─────────
export interface Register {
  registerFlavor(id: string, opts: { name: string; multiplier: number; unlockCost: number; color?: string; description?: string; seasonal?: string }): void;
  registerCountry(id: string, opts: { name: string; multiplier: number; cost: number; description?: string; images?: string[] }): void;
  registerBackground(opts: { name: string; image: string }): void;
  registerCombo(id: string, opts: { name: string; flavors: string[]; multiplier: number; description?: string }): void;
  registerShop(id: string, opts: { name: string; baseCost: number; baseIncome: number; costMultiplier?: number }): void;
  registerEmployee(id: string, opts: { name: string; baseCost: number; baseIncome: number; costMultiplier?: number }): void;
  registerUpgrade(id: string, opts: { name: string; baseCost: number; costMultiplier?: number; maxLevel: number; effect?: string; description?: string; category?: string; section?: string }): void;
  registerLocation(id: string, opts: { name: string; baseCost: number; costMultiplier?: number; description?: string }): void;
}
export const register: Register;
