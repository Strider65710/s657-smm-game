# Lucky Blends (example code mod)

Extends game logic at a hook point: bumps total income +10% and taps the manual
blend calculation. **Code mod** = runs JavaScript, so the game asks for consent
before enabling it.

## What the game reads
- `mod.json` - manifest (`type: "code"`, points at `dist/main.js`).
- `dist/main.js` - the pre-compiled entry the game evaluates in the mod sandbox.
  `hooks` and a read-only `gameApi` are provided in scope.
- `assets/icon.png` - Mods-panel icon (add your own).

## What the game ignores
- `src/main.ts` - author source. Compile it to `dist/main.js` yourself; the
  game never compiles TypeScript.

## Hook points used
Both ids come from `../../docs.md` (the only functions that are hookable):
- `game/logic.ts@calcGlobalMultiplier` - `append` scales the final global
  income multiplier.
- `game/logic.ts@calcManualBlendGain` - `prepend` taps the manual-blend payout
  (no-op here, for illustration).

## Handler kinds
- `append(id, fn)` - runs after; `fn(returnValue)` returns a replacement. Stacks
  with other mods in alphabetical load order.
- `prepend(id, fn)` - runs before; can transform inputs.
- `override(id, fn)` - replaces the implementation. Use sparingly (conflicts
  warn; alphabetically-last mod wins).
