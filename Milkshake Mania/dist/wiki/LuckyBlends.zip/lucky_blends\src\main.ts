// Author-side source (NOT read by the game - the game runs ../dist/main.js).
// Write TypeScript here, compile it to dist/main.js with the mod authoring kit
// before zipping. The game does not compile TypeScript.
//
// `hooks` (and a read-only `gameApi`) are provided by the mod sandbox scope;
// in source you import them from the modkit types for autocompletion.

import { hooks } from "@smm/modkit";

// Lucky Blends: nudge total income up 10%. `append` runs AFTER the hooked
// function and receives its return value; return a replacement.
hooks.append("game/logic.ts@calcGlobalMultiplier", (value: number) => {
  return value * 1.1;
});

// `prepend` runs BEFORE the function and can inspect/transform inputs. This one
// is a no-op tap that just demonstrates the shape.
hooks.prepend("game/logic.ts@calcManualBlendGain", (ctx: unknown) => {
  return ctx;
});
