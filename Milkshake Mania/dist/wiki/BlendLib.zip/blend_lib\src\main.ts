import { gameApi } from "@smm/modkit";

/**
 * Blend Lib — a LIBRARY mod (type: "lib"). It registers no content and changes
 * nothing on its own. Everything it `export`s becomes the value other mods get
 * from `require("blend_lib")`, because the loader publishes a lib mod's
 * module.exports under its namespace and loads it before its dependents.
 *
 * (Built with esbuild --format=cjs, so each `export` below becomes a property on
 * module.exports — exactly what require() returns.)
 */

export const version = "1.0.0";

/** Turn a percentage into a multiplier: pctBonus(5) -> 1.05. Clamped sanely. */
export function pctBonus(pct: number): number {
  const p = Math.max(-90, Math.min(500, Number(pct) || 0));
  return 1 + p / 100;
}

/** Format a number with the game's own formatter (falls back to String). */
export function formatBig(n: number): string {
  try {
    return gameApi.format.number(n);
  } catch {
    return String(n);
  }
}

/** A fun "blender rank" label derived from lifetime blends. */
export function tierLabel(blends: number): string {
  if (blends >= 1_000_000) return "Legendary Blender";
  if (blends >= 100_000) return "Master Blender";
  if (blends >= 10_000) return "Pro Blender";
  if (blends >= 1_000) return "Apprentice";
  return "Rookie";
}
