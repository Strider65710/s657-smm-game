// Author-side source (NOT read by the game - the game runs ../dist/main.js).
//
// Tycoon Mode: a full, real code mod that touches MANY hook points at once to
// deliver a cohesive "power fantasy" economy overhaul, and ships its own flavor
// (see ../registry.json) - proof that a code mod is a superset of an asset mod.
//
// Every id used here is listed as wired/hookable in ../../docs.md.

import { hooks, gameApi, mods, crash, ui } from "@smm/modkit";

// --- Income: triple passive income, and buff the prestige multiplier. ---
hooks.append("game/logic.ts@calcIncomePerSecond", (v: number) => v * 3);
hooks.append("game/logic.ts@calcPrestigeMultiplier", (v: number) => v + 0.5);

// --- Progression: level up faster, and double the level-up cash reward. ---
hooks.append("game/leveling.ts@xpForLevelUp", (v: number) =>
  Math.max(1, Math.floor(v * 0.6)),
);
hooks.append("game/leveling.ts@levelUpReward", (v: number) => v * 2);

// --- Pricing: cheaper countries and shops so you expand aggressively. ---
hooks.append("constants.ts@scaledCountryCost", (v: number) =>
  Math.floor(v * 0.5),
);
hooks.append("registry.ts@shopCost", (v: number) => Math.floor(v * 0.8));

// --- Reputation: a small permanent bump to customer rating. ---
hooks.append("game/logic.ts@calcCustomerRating", (v: number) =>
  Math.min(5, v + 0.5),
);

// Compatibility: `mods` lists the active mods; `crash(reason)` is a controlled
// emergency exit (auto-disables this mod, save untouched). Uncomment to gate on
// another mod's presence:
// if (!mods.has("some_dependency")) crash("Tycoon Mode requires some_dependency.");
// if (mods.has("no_tycoon")) crash("Incompatible with no_tycoon.");

// UI injection: a whole new main-menu button, added by a mod. This one is a
// joke/demo - it deliberately triggers the runtime emergency exit so you can
// see crash handling in action (mod auto-disables, game reloads, save safe).
ui.addMenuButton({
  label: "Crash",
  icon: "alert-triangle",
  onClick: () => crash("You pressed the big red button. Congratulations?"),
});

// gameApi is a frozen read-only surface - handy for logging / sanity checks.
console.log(
  `[Tycoon Mode] loaded on API ${gameApi.apiVersion}. ` +
    `Base shake sale: ${gameApi.format.money(gameApi.constants.BASE_SHAKE_SALE)}. ` +
    `Active mods: ${mods.list().map((m) => m.namespace).join(", ")}`,
);
void crash; // referenced above (commented); keep the import meaningful
