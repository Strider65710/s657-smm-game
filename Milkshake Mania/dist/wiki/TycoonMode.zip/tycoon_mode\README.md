# Tycoon Mode (full example code mod)

A complete, real mod that overhauls the economy by combining **seven hook
points** and ships **its own flavor** - a working demonstration that a code mod
is a superset of an asset mod.

## What it does
| System | Hook | Effect |
|---|---|---|
| Passive income | `game/logic.ts@calcIncomePerSecond` | ×3 |
| Prestige power | `game/logic.ts@calcPrestigeMultiplier` | +0.5 |
| Leveling speed | `game/leveling.ts@xpForLevelUp` | ×0.6 XP needed |
| Level rewards | `game/leveling.ts@levelUpReward` | ×2 cash |
| Country prices | `constants.ts@scaledCountryCost` | ×0.5 |
| Shop prices | `registry.ts@shopCost` | ×0.8 |
| Reputation | `game/logic.ts@calcCustomerRating` | +0.5 stars (cap 5) |

Plus a new flavor **Gold Rush** (`tycoon_mode:flavors/gold_rush`) via
`registry.json`.

## Files the game reads
- `mod.json` - `type: "code"`, `changesGameplay: true`, points at both
  `registry.json` and `dist/main.js`.
- `registry.json` - the Gold Rush flavor (applied first).
- `dist/main.js` - the compiled hooks (run after consent).

## Try it (once the v1.4 loader is enabled)
1. Zip the `tycoon_mode/` folder into `TycoonMode.zip`.
2. Main Menu -> Mods -> Install -> pick the zip.
3. Enable it, tick the code-consent box (it changes gameplay), then Reload.
4. Watch income, leveling, and prices shift; Gold Rush appears in Flavors. Open
   the browser console to see the mod's load line.

## Author workflow
Write `src/main.ts` in TypeScript, compile it to `dist/main.js` (the game does
not compile TS), then zip. `hooks` and `gameApi` are provided in scope - no
runtime imports needed.
