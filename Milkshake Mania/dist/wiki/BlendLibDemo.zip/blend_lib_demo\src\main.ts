import { hooks, gameApi, ui } from "@smm/modkit";

// A library mod is imported by its NAMESPACE. Because we listed "blend_lib" in
// this mod's `dependencies`, the loader loads it first and resolves this
// require() to its exports. (The build marks declared deps external, so this
// require call survives into dist/main.js instead of being bundled.)
declare const require: (id: string) => any;
const lib = require("blend_lib") as {
  version: string;
  pctBonus: (pct: number) => number;
  formatBig: (n: number) => string;
  tierLabel: (blends: number) => string;
};

// Use the library's helper to apply a +5% global income bonus.
hooks.append("game/logic.ts@calcGlobalMultiplier", (v: number) =>
  v * lib.pctBonus(5),
);

ui.addMenuButton({
  label: "Lib Demo",
  icon: "puzzle",
  onClick: () => {
    const s = gameApi.stats();
    const blends = s ? s.totalMilkshakes : 0;
    ui.modal({
      title: "Blend Lib Demo",
      icon: "puzzle",
      text:
        `blend_lib v${lib.version}\n` +
        `Your rank: ${lib.tierLabel(blends)}\n` +
        `Lifetime blends: ${lib.formatBig(blends)}\n\n` +
        `This mod applies +5% global income using the shared library.`,
    });
  },
});
