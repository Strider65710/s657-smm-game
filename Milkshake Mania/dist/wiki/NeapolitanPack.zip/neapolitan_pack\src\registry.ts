// Author-side source (NOT read by the game). neapolitan_pack ships as an ASSET
// mod: the real artifact is ../registry.json, which the game consumes directly —
// no build step needed for asset mods. This file shows the EQUIVALENT code-mod
// form: the same three flavors registered imperatively through the injected
// `register` API. Build it like any code mod (`node ../build.mjs neapolitan_pack`)
// if you'd rather ship a dist/main.js than registry.json — you don't need both.
//
// register.registerFlavor(id, { name, multiplier, unlockCost, color, description })
//   - `id` is the path portion of the regId; the game prefixes it with this
//     mod's namespace -> "neapolitan_pack:flavors/strawberry_swirl".

import { register } from "@smm/modkit";
import { ModFlavorType } from "./types";

register.registerFlavor("strawberry_swirl", {
  name: ModFlavorType.STRAWBERRY_SWIRL,
  multiplier: 3.2,
  unlockCost: 250000,
  color: "#f472b6",
  description: "A bright ribbon of real strawberry through creamy vanilla.",
});

register.registerFlavor("vanilla_bean", {
  name: ModFlavorType.VANILLA_BEAN,
  multiplier: 2.6,
  unlockCost: 90000,
  color: "#fde68a",
  description: "Speckled Madagascar vanilla - simple, classic, dependable.",
});

register.registerFlavor("dark_chocolate", {
  name: ModFlavorType.DARK_CHOCOLATE,
  multiplier: 3.8,
  unlockCost: 480000,
  color: "#78350f",
  description: "70% cocoa for the grown-up palate.",
});
