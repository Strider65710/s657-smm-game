// Author-side source (NOT read by the game). Optional TypeScript reference for
// the flavors this mod adds. neapolitan_pack ships as an ASSET mod — its real,
// game-consumed artifact is ../registry.json (hand-authored declarative JSON).
// This src/ shows the equivalent CODE-mod form for authors who prefer TS.

export enum ModFlavorType {
  STRAWBERRY_SWIRL = "Strawberry Swirl",
  VANILLA_BEAN = "Vanilla Bean",
  DARK_CHOCOLATE = "Dark Chocolate",
}
