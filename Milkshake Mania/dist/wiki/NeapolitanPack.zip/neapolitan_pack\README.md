# Neapolitan Pack (example asset mod)

Adds three flavors to the game. **Asset mod** = pure data, no code, no risk.

## What the game reads
- `mod.json` - manifest (`type: "asset"`, points at `registry.json`).
- `registry.json` - the declarative content. Each flavor becomes a namespaced
  regId: `neapolitan_pack:flavors/<id>`.
- `assets/icon.png` - the mod's icon in the Mods panel (add your own).

## What the game ignores
- `src/` - the optional TypeScript authoring form. The authoring kit compiles
  `src/registry.ts` into `registry.json`. Shipped here only for readability.

## Try it (once the v1.4 loader exists)
1. Zip the `neapolitan_pack/` folder into `NeapolitanPack.zip`.
2. Main Menu -> Mods -> Install -> pick the zip.
3. Reload. The three flavors appear in the Flavors tab, unlockable at their
   listed costs.
