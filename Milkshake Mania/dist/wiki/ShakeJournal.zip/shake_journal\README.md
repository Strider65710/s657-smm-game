# Shake Journal (full example: the complete v1.4 mod scope)

A stateful companion mod that uses **every** part of the v1.4 mod scope working
together - the reference example for reactive, persistent, UI-adding mods.

## What it demonstrates

| API | Used for |
|---|---|
| `events.on("blend")` / `events.on("prestige")` | Reacting to gameplay as it happens |
| `storage.get` / `storage.set` | Lifetime stats that survive reloads (per-mod, namespaced) |
| `hooks.append("game/logic.ts@calcGlobalMultiplier")` | An income bonus fed by the STORED stats: +0.5% per 1,000 lifetime blends, capped +25% |
| `ui.addMenuButton` | A "Journal" button on the main menu that shows your stats |
| `gameApi.format` | Formatting the numbers in the journal popup |
| `registry.json` (`countries`) | A bundled country - **Atlantis** (`shake_journal:countries/atlantis`) |

## Why it's interesting

The pieces feed each other: events update state, storage persists it, the hook
reads it back into the economy, and the UI displays it. That loop - react,
remember, affect, show - is the shape of most real mods.

## Try it
1. Zip the `shake_journal/` folder into `ShakeJournal.zip`.
2. Main Menu -> Mods -> Install -> enable -> consent -> Reload.
3. Blend some shakes, then click **Journal** on the main menu.
4. Atlantis appears in the Countries tab.
