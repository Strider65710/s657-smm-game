// Author-side source (NOT read by the game - the game runs ../dist/main.js).
// Compile this to dist/main.js before zipping; the game does not compile TS.
//
// Shake Journal demonstrates the full v1.4 mod scope working together:
//   events  - subscribe to "blend" / "prestige" lifecycle events
//   storage - persist stats across sessions (per-mod, namespaced)
//   hooks   - an income bonus that grows with the stored stats
//   ui      - a "Journal" main-menu button showing the stats
//   registry.json - a bundled country (Atlantis)

import { hooks, gameApi, events, storage, ui } from "@smm/modkit";

let lifetimeBlends = storage.get<number>("lifetimeBlends", 0);
let lifetimeSpecials = storage.get<number>("lifetimeSpecials", 0);
let prestiges = storage.get<number>("prestiges", 0);
let sessionBlends = 0;

const save = () => {
  storage.set("lifetimeBlends", lifetimeBlends);
  storage.set("lifetimeSpecials", lifetimeSpecials);
  storage.set("prestiges", prestiges);
};

events.on("blend", (e: { gain: number; special: boolean }) => {
  sessionBlends += 1;
  lifetimeBlends += 1;
  if (e?.special) lifetimeSpecials += 1;
  if (lifetimeBlends % 25 === 0) save(); // throttle writes
});

events.on("prestige", () => {
  prestiges += 1;
  save();
});

// +0.5% income per 1,000 lifetime blends, capped at +25%.
const journalBonus = () =>
  Math.min(0.25, Math.floor(lifetimeBlends / 1000) * 0.005);

hooks.append("game/logic.ts@calcGlobalMultiplier", (v: number) =>
  v * (1 + journalBonus()),
);

ui.addMenuButton({
  label: "Journal",
  icon: "book-open",
  onClick: () => {
    ui.modal({
      title: "Shake Journal",
      icon: "book-open",
      html: `
        <ul style="margin:0;padding-left:1.1rem;line-height:1.7">
          <li>Lifetime blends: <b>${gameApi.format.number(lifetimeBlends)}</b></li>
          <li>Lifetime specials: <b>${gameApi.format.number(lifetimeSpecials)}</b></li>
          <li>Rebrands witnessed: <b>${prestiges}</b></li>
          <li>Blends this session: <b>${sessionBlends}</b></li>
          <li>Journal income bonus: <b>+${(journalBonus() * 100).toFixed(1)}%</b></li>
        </ul>
      `,
    });
  },
});

console.log(`[Shake Journal] loaded. Lifetime blends so far: ${lifetimeBlends}`);
